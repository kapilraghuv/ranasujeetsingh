
			<section class="page_copyright ds ms s-pt-30 s-pb-20 c-mb-10 c-mb-lg-0 s-py-lg-20">
				<div class="container">
					<div class="row align-items-center">
						<div class="divider-25 d-none d-lg-block"></div>
						<div class="col-lg-8">
							<div class="social-icons social-icons-tilled text-center text-lg-left w-100">
								<a href="https://www.facebook.com/ranasujeetsingh2/" class="fab fa-facebook-square" title="facebook" target="_blank"><span>facebook</span></a>
								<a href="https://twitter.com/sujeet5981" class="fab fa-twitter-square " title="twitter" target="_blank"><span>twitter</span> </a>
								<a href="https://www.instagram.com/rana_sujeet_singh/" class="fab fa-instagram " title="instagram"><span>instagram</span></a>
								<a href="https://www.youtube.com/channel/UCi-QM1a2p5roVjYE7L3AWCw" class="fab fa-youtube" title="youtube"><span>youtube</span></a>
							</div>
						</div>
						<div class="col-lg-4 text-center text-lg-right">
							<p>Copyright <span class="copyright_year">2019</span> All Rights Reserved</p>
						</div>
						<div class="divider-25 d-none d-lg-block"></div>
					</div>
				</div>
			</section>


		</div><!-- eof #box_wrapper -->
	</div><!-- eof #canvas -->


	<script src="js/compressed.js"></script>
	<script src="js/main.js"></script>
	

</body>



</html>
			